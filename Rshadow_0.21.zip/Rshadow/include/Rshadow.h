#include <Rcpp.h>
#include <shadowc.h>